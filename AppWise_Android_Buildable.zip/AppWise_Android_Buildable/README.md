# AppWise Android
Native Android starter. AGP 8.7.3, Gradle 8.9, Kotlin 2.0.21, JDK 17, SDK 35.
