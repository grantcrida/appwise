plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "zw.maxmotors.appwise"; compileSdk = 35; defaultConfig { applicationId = "zw.maxmotors.appwise"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" } }
kotlin { jvmToolchain(17) }
