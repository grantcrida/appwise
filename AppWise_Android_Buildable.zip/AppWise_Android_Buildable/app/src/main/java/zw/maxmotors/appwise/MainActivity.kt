package zw.maxmotors.appwise
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
class MainActivity: Activity(){
 private val navy=Color.rgb(12,22,40); private val green=Color.rgb(27,190,123); private val white=Color.WHITE; private val muted=Color.rgb(175,190,205)
 override fun onCreate(b:Bundle?){super.onCreate(b); home()}
 private fun home(){val s=ScrollView(this);s.setBackgroundColor(navy);val p=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,28,22,24)};s.addView(p);setContentView(s)
  p.addView(t("AppWise",30f,green,true));p.addView(t("Make your data work smarter.",15f,muted,false));p.addView(space(18));
  p.addView(sec("SCHEDULE"));p.addView(t("Shared window for AppWise-managed transfers.",14f,muted,false));p.addView(field("Start time (e.g. 23:00)"));p.addView(space(8));p.addView(field("End time (e.g. 05:00)"));p.addView(space(10));p.addView(btn("Save schedule"){Toast.makeText(this,"Schedule saved in prototype mode.",Toast.LENGTH_SHORT).show()})
  p.addView(space(22));p.addView(sec("DATA USAGE"));p.addView(t("AppWise will use Android Usage Access for usage statistics. Live monitoring is the next development stage.",14f,muted,false));p.addView(space(10));p.addView(btn("Open Usage Access settings"){startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))})
  p.addView(space(22));p.addView(sec("TRANSFER QUEUE"));p.addView(t("No transfers yet. The next stage adds queued files, progress, pause/resume and retry.",14f,muted,false));p.addView(space(22));p.addView(sec("APPWISE CONNECT"));p.addView(t("Internet messaging, groups and secure file sharing will be added in the next development stages.",14f,muted,false));p.addView(space(22));p.addView(sec("IMPORTANT"));p.addView(t("AppWise will not automatically switch mobile data or Wi‑Fi, and it cannot guarantee carrier night-bundle billing.",13f,muted,false))}
 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine();setTextColor(white);setHintTextColor(muted);setBackgroundColor(Color.rgb(24,38,57));setPadding(14,12,14,12)}
 private fun t(v:String,z:Float,c:Int,b:Boolean)=TextView(this).apply{text=v;textSize=z;setTextColor(c);if(b)setTypeface(typeface,Typeface.BOLD)}
 private fun sec(v:String)=TextView(this).apply{text=v;textSize=17f;setTextColor(white);setTypeface(typeface,Typeface.BOLD);setPadding(0,0,0,8)}
 private fun space(h:Int)=TextView(this).apply{height=h}
 private fun btn(v:String,a:()->Unit)=Button(this).apply{text=v;setTextColor(Color.WHITE);setBackgroundColor(green);setOnClickListener{a()};isAllCaps=false}
}
